from .Simple_Notify_Discord import Simple_Notify_Discord

__all__ = ["Simple-Notify-discord"]
